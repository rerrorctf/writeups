#!/usr/bin/env python3

from pwn import *
from collections import Counter
from functools import reduce
from operator import add

context.update(arch='x86_64')

def bytes_to_c_arr(b):
    s = ''
    for x in b:
        s += hex(x) + ', '
    return s

# regs:
# r15: data base
# r14: data index (r14+r15 - data pointer)
# rcx, rdx, r11: clobbered by syscalls
# r13: '[' signature
# r12: ']' signature
# r10: offset from found '[' signature to end of '['
# r9: offset from found ']' signature to end of ']'
# r8: offset in '[' from loading rip to end of ']'
# rsp: offset in ']' from loading rip to start of ']'

instructions = {}

data_size = 0x1000

instructions['>'] = asm(
    'inc r14;' +
    f'and r14, {hex(data_size-1)};'
)

instructions['<'] = asm(
    f'add r14, {hex(data_size-1)};' +
    f'and r14, {hex(data_size-1)};'
)

instructions['+'] = asm(
    'inc byte ptr [r14 + r15];'
)

instructions['-'] = asm(
    'dec byte ptr [r14 + r15];'
)

instructions['.'] = asm(
    'xor rax, rax; mov al, 1;' + # rax = 1 - syscall: write
	'mov rdi, 1;' + # rdi = 1 - fd: stdout
	'lea rsi, [r14+r15];' + # rsi = rbx - buff: current char
	'xor rdx, rdx; mov dl, 1;' +  # rdx = 1 - count: 1
	'syscall;' # write(stdout, rbx, 1)
)

instructions['['] = asm(
    'nop;' +
    'cmp byte ptr [r14 + r15], 0;' +
    'jnz end;' + # move to next instruction if not zero
    'lea rdi, [rip];' + # rdi - index for searching brackets
    'add rdi, r8;' + # skip this instruction (r8 has an offset to the end)
    'mov rcx, 1;' + # rcx - current bracket balance (lbrackets - rbrackets)
    'mov rax, r13;' + # al - '[' signature
    'mov rbx, r12;' + # bl - ']' signature

    'loop:' +
        'inc rdi;' + # until brackets are balanced

        'cmp byte ptr [rdi], al;' +
        'jne no_lbracket;' + # if left bracket found
        'inc rcx;' + # add to balance
        'no_lbracket:' +

        'cmp byte ptr [rdi], bl;' +
        'jne no_rbracket;' + # if right bracket found
        'dec rcx;' + # remove from balance
        'no_rbracket:' +

        'test rcx, rcx;' + # end when brackets are balanced
        'jnz loop;' +

    'add rdi, r9;' + # add offset from found ']' signature to end of this instruction
    'jmp rdi;' + # jump after instruction
    'end:'
)

instructions[']'] = asm(
    'cmp byte ptr [r14 + r15], 0;' +
    'jz end;' + # move to next instruction if zero
    'lea rdi, [rip];' + # rdi - index for searching brackets
    'sub rdi, rsp;' + # skip this instruction (search will go backwards)
    'mov rcx, 1;' + # rcx - current bracket balance (rbrackets - lbrackets)
    'mov rax, r13;' + # al - '[' signature
    'mov rbx, r12;' + # bl - ']' signature

    'loop:' +
        'dec rdi;' + # going left until brackets are balanced

        'cmp byte ptr [rdi], al;' +
        'jne no_lbracket;' + # if left bracket found
        'dec rcx;' + # remove from balance
        'no_lbracket:' +

        'cmp byte ptr [rdi], bl;' +
        'jne no_rbracket;' + # if right bracket found
        'inc rcx;' + # add to balance
        'no_rbracket:' +

        'test rcx, rcx;' + # end when brackets are balanced
        'jnz loop;' +

    'add rdi, r10;' + # add offset from found '[' signature to end of this instruction
    'jmp rdi;' + # jump after instruction
    'end:'
)
for instr_name in instructions:
    print(f'{instr_name}: {bytes_to_c_arr(instructions[instr_name])}')

all_code = reduce(add, instructions.values())
rcond_only = []
lcond_only = []
counter = Counter(all_code)
for b in counter:
    if counter[b] == 1:
        if b in instructions[']']:
            rcond_only.append(b)
        if b in instructions['[']:
            lcond_only.append(b)

print(f'bytes only in "[": {lcond_only}, only in "]": {rcond_only}')
assert(len(lcond_only) > 0)
assert(len(rcond_only) > 0)

with open('instructions.cpp', 'w') as instr_f:
    instr_f.write('const map<char, vector<byte>> instructions = {\n')
    for instr in instructions:
        instr_f.write("\t{'" + instr + "', {" + bytes_to_c_arr(instructions[instr]) + '}},\n')
    instr_f.write('};\n\n')

    instr_f.write('const vector<byte> lcond_only_bytes = {' + bytes_to_c_arr(lcond_only) + '};\n')
    instr_f.write('const vector<byte> rcond_only_bytes = {' + bytes_to_c_arr(rcond_only) + '};\n\n')

    instr_f.write('const int lcond_signature_to_end = 58;\n')
    instr_f.write('const int lcond_rip_load_to_end = 40;\n')
    instr_f.write('const int rcond_signature_to_end = 52;\n')
    instr_f.write('const int rcond_rip_load_to_end = 15;\n\n')

    instr_f.write(f'const int DATA_SIZE = {hex(data_size)};\n')
