#include <iostream>
#include <iomanip>
#include <map>
#include <vector>
#include <cstring>

#include <sys/mman.h>

using std::vector, std::map, std::string;

using byte = unsigned char;

#include "instructions.cpp"

template<typename T>
void vector_append(vector<T>& into, const vector<T>& from) {
	into.insert(into.end(), from.begin(), from.end());
}

vector<byte> compile(const string& code) {
	vector<byte> compiled;
	const vector<byte> compiled_end = {
		0x48, 0xC7, 0xC0, 0x3C, 0x00, 0x00, 0x00, // mov rax, 0x3c
		0x0F, 0x05 // syscall (exit())
	};
	for (char c: code) {
		auto found_instruction = instructions.find(c);
		if(found_instruction != instructions.end()) {
			vector_append<>(compiled, found_instruction->second);
		}
	}
	vector_append(compiled, compiled_end);
	return compiled;
}

std::string read_code() {
	std::string code;
	std::cin >> std::setw(0x4000) >> code;
	return code;
}

void print_instruction() {
	std::setbuf(stdin, nullptr);
	std::setbuf(stdout, nullptr);

	std::cout << "Welcome to blazing fast brainfuck compiler!\n";
	std::cout << "Compile your brainfuck code into highly optimized native code to execute your brainfuck code faster then ever!\n";
	std::cout << "(compiled code is always faster, right?)\n";

	std::cout << "Some example programs:\n";
	std::cout << "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.\n";
	std::cout << "++++++++[>+>++++<<-]>++>>+<[-[>>+<<-]+>>]>+[-<<<[->[+[-]+>++>>>-<<]<[<]>>++++++[<<+++++>>-]+<<++.[-]<<]>.>+[>>]>+]\n";

	std::cout << "Enter your code:\n";
}

void execute_code(vector<byte> compiled) {
	char* code_mem = (char*) mmap(nullptr, compiled.size() + DATA_SIZE, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);
	std::memcpy(code_mem, compiled.data(), compiled.size());
	char* data_mem = code_mem + compiled.size();

	long rcond_signature = rcond_only_bytes[0];
	long lcond_signature = lcond_only_bytes[0];

	asm (
			"mov rsp, %0;" // rsp: offset in ']' from loading rip to start of ']'
			"mov r8, %1;" // r8: offset in '[' from loading rip to end of ']'
			"mov r9, %2;" // r9: offset from found ']' signature to end of ']'
			"mov r10, %3;" // r10: offset from found '[' signature to end of '['
			"mov r12, %4;" // signature of ] in r12
			"mov r13, %5;" // signature of [ in r13
			"mov r14, 0;" // data index in r14
			"mov r15, %6;" // data pointer in r15
			"jmp %7;" // jump into compiled code
			: // no output
			: 
			"i" (rcond_rip_load_to_end), "i" (lcond_rip_load_to_end),
			"i" (rcond_signature_to_end), "i" (lcond_signature_to_end),
			"r" (rcond_signature), "r" (lcond_signature),
			"r" (data_mem), "r" (code_mem)
		);
}

int main() {
	print_instruction();
	vector<byte> compiled_code = compile(read_code());
	execute_code(compiled_code);
}

