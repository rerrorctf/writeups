#!/usr/bin/env python3

import os
import random
import signal
import stat
import string
import struct
import subprocess
import sys

def random_token(size=20):
    return '/tmp/' + ''.join(random.choices(string.ascii_letters + string.digits, k=size))

def alarm_handler(sig, frame):
    sys.exit()

class TempFile:
    def __enter__(self):
        self.file = open(random_token(), 'xb')
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.file.closed:
            self.file.close()
        os.remove(self.file.name)

def main():
    CHUNK_SIZE = 0x1000

    signal.signal(signal.SIGALRM, alarm_handler)
    signal.alarm(120)

    print('gimme a file to run: <size, 2 bytes, big endian><file>')
    filesize = struct.unpack('!H', sys.stdin.buffer.read(2))[0]

    with TempFile() as f:
        to_read = filesize
        while to_read > 0:
            chunk = sys.stdin.buffer.read(min(to_read, CHUNK_SIZE))
            f.file.write(chunk)
            to_read -= len(chunk)

        f.file.close()
        st = os.stat(f.file.name)
        os.chmod(f.file.name, st.st_mode | stat.S_IEXEC)

        subprocess.run([f.file.name], env={'LD_PRELOAD': './libsec.so'})

main()
